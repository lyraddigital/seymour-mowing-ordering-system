import { redirect } from "react-router";

import type { Route } from "./+types/jobs.$jobId.invoices.create";
import { PermissionDeniedError } from "../server/auth/authorization/errors/permission-denied-error";
import { currentUserContext } from "../server/auth/context/current-user-context";
import { runtimeContext } from "../server/auth/context/runtime-context";
import { createDraftInvoice } from "../server/features/invoices/services/create-draft-invoice.server";
import { JobNotFoundError } from "../server/features/jobs/errors/job-not-found-error";

export async function action({ context, params }: Route.ActionArgs) {
  try {
    const result = await createDraftInvoice(
      context.get(runtimeContext).env.DB,
      context.get(currentUserContext),
      params.jobId,
    );

    return redirect(`/invoices/${result.id}`);
  } catch (error) {
    if (error instanceof JobNotFoundError) {
      throw new Response("Job not found", {
        status: 404,
      });
    }

    if (error instanceof PermissionDeniedError) {
      throw new Response("Forbidden", {
        status: 403,
      });
    }

    throw error;
  }
}

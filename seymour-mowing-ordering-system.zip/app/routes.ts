import {
  type RouteConfig,
  index,
  route,
  layout,
} from "@react-router/dev/routes";
export default [
  layout("routes/app-layout.tsx", [
    index("routes/index.ts"),
    route("dashboard", "routes/dashboard.tsx"),
    route("customers", "routes/customers.tsx"),
    route("jobs", "routes/jobs.tsx"),
    route("jobs/new", "routes/jobs.new.tsx"),
    route("jobs/history", "routes/jobs.history.tsx"),
    route("jobs/:jobId/items/new", "routes/jobs.$jobId.items.new.tsx"),
    route(
      "jobs/:jobId/items/:itemId/edit",
      "routes/jobs.$jobId.items.$itemId.edit.tsx",
    ),
    route(
      "jobs/:jobId/items/:itemId/delete",
      "routes/jobs.$jobId.items.$itemId.delete.tsx",
    ),
    route("jobs/:jobId", "routes/jobs.$jobId.tsx"),
    route("jobs/:jobId/edit", "routes/jobs.$jobId.edit.tsx"),
    route("jobs/:jobId/complete", "routes/jobs.$jobId.complete.tsx"),
    route("jobs/:jobId/start", "routes/jobs.$jobId.start.tsx"),
    route("jobs/:jobId/cancel", "routes/jobs.$jobId.cancel.tsx"),
    route(
      "invoices/:invoiceId/items/new",
      "routes/invoices.$invoiceId.items.new.tsx",
    ),
    route(
      "invoices/:invoiceId/items/:itemId/edit",
      "routes/invoices.$invoiceId.items.$itemId.edit.tsx",
    ),
    route(
      "invoices/:invoiceId/items/:itemId/delete",
      "routes/invoices.$invoiceId.items.$itemId.delete.tsx",
    ),
    route(
      "invoices/:invoiceId/payments/new",
      "routes/invoices.$invoiceId.payments.new.tsx",
    ),
    route(
      "invoices/:invoiceId/payments/:paymentId/void",
      "routes/invoices.$invoiceId.payments.$paymentId.void.ts",
    ),
    route("invoices", "routes/invoices.tsx"),
    route("payments", "routes/payments.tsx"),
    route("invoices/:invoiceId", "routes/invoices.$invoiceId.tsx"),
    route("invoices/:invoiceId/edit", "routes/invoices.$invoiceId.edit.tsx"),
    route("invoices/:invoiceId/issue", "routes/invoices.$invoiceId.issue.ts"),
    route("invoices/:invoiceId/void", "routes/invoices.$invoiceId.void.ts"),
    route("invoices/:invoiceId/delete", "routes/invoices.$invoiceId.delete.ts"),
    route("invoices/new", "routes/invoices.new.tsx"),
    route(
      "customers/:customerId/archive",
      "routes/customers.$customerId.archive.tsx",
    ),
    route(
      "customers/:customerId/restore",
      "routes/customers.$customerId.restore.tsx",
    ),
    route("customers/archived", "routes/customers.archived.tsx"),
    route("customers/new", "routes/customers.new.tsx"),
    route(
      "customers/:customerId/edit",
      "routes/customers.$customerId.edit.tsx",
    ),
    route("customers/:customerId", "routes/customers.$customerId.tsx"),
  ]),
] satisfies RouteConfig;

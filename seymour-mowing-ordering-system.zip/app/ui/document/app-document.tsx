import { Links, Meta, Scripts, ScrollRestoration } from "react-router";

type AppDocumentProps = {
  children: React.ReactNode;
};

export function AppDocument({ children }: AppDocumentProps) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <Meta />
        <Links />
      </head>

      <body>
        {children}

        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}

import { Link } from "react-router/internal/react-server-client";

import type { CustomerSummary } from "../../../../../server/features/customers/types/customer-summary";
import styles from "./customer-list.module.css";

export default function CustomerList({
  customers,
  label = "Active customers",
}: {
  customers: CustomerSummary[];
  label?: string;
}) {
  return (
    <ul className={styles.list} aria-label={label}>
      {customers.map((customer) => {
        const locality = [customer.suburb, customer.state, customer.postcode]
          .filter(Boolean)
          .join(" ");

        const address = [customer.addressLine1, customer.addressLine2, locality]
          .filter(Boolean)
          .join(", ");

        return (
          <li key={customer.id} className={styles.customer}>
            <h2 className={styles.customerName}>
              <Link
                className={styles.customerLink}
                to={`/customers/${customer.id}`}
              >
                {customer.name}
              </Link>
            </h2>

            {(customer.email || customer.phone) && (
              <dl className={styles.contact}>
                {customer.email && (
                  <div>
                    <dt>Email</dt>
                    <dd>
                      <a href={"mailto:" + customer.email}>{customer.email}</a>
                    </dd>
                  </div>
                )}

                {customer.phone && (
                  <div>
                    <dt>Phone</dt>
                    <dd>
                      <a href={"tel:" + customer.phone}>{customer.phone}</a>
                    </dd>
                  </div>
                )}
              </dl>
            )}

            {address && (
              <dl className={styles.address}>
                <div>
                  <dt>Address</dt>
                  <dd>{address}</dd>
                </div>
              </dl>
            )}
          </li>
        );
      })}
    </ul>
  );
}

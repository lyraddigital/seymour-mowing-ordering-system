import { useRef, useState } from "react";

import type { CreateJobFieldErrors } from "../../../../../server/features/jobs/types/create-job-input";
import type { JobItemFormValues } from "../../../../../server/features/jobs/validation/parse-job-item-form";
import ui from "../../../../styles/product.module.css";
import styles from "./initial-job-charges.module.css";

interface InitialJobChargesProps {
  values?: JobItemFormValues[];
  fieldErrors?: CreateJobFieldErrors;
  disabled: boolean;
}

export default function InitialJobCharges({ values = [], fieldErrors, disabled }: InitialJobChargesProps) {
  const nextId = useRef(values.length);
  const [rows, setRows] = useState(() => values.map((value, index) => ({
    id: index,
    values: value,
    errors: {
      description: fieldErrors?.[`charges[${index}].description`],
      quantity: fieldErrors?.[`charges[${index}].quantity`],
      unitPrice: fieldErrors?.[`charges[${index}].unitPriceCents`],
    },
  })));

  return (
    <section className={styles.section} aria-labelledby="additional-charges-heading">
      <header>
        <h2 id="additional-charges-heading">Additional charges</h2>
        <p>Optional charges for this job. You can also add them later.</p>
      </header>
      {rows.map((row, index) => (
        <fieldset key={row.id} className={styles.charge} disabled={disabled}>
          <legend>Charge {index + 1}</legend>
          <div className={styles.fields}>
            {(["description", "quantity", "unitPrice"] as const).map((field) => {
              const id = `charge-${row.id}-${field}`;
              const error = row.errors[field];
              return (
                <div key={field} className={field === "description" ? styles.description : undefined}>
                  <label htmlFor={id}>{field === "description" ? "Description" : field === "quantity" ? "Quantity" : "Unit price"}</label>
                  <div className={field === "unitPrice" ? styles.moneyField : undefined}>
                    {field === "unitPrice" && <span aria-hidden="true">$</span>}
                    <input id={id} name={`charges[${index}].${field}`}
                      type={field === "quantity" ? "number" : "text"}
                      inputMode={field === "unitPrice" ? "decimal" : undefined}
                      min={field === "quantity" ? "1" : undefined}
                      step={field === "quantity" ? "1" : undefined}
                      maxLength={field === "description" ? 500 : undefined}
                      defaultValue={row.values[field]} required
                      aria-invalid={!!error}
                      aria-describedby={error ? `${id}-error` : field === "unitPrice" ? `${id}-hint` : undefined}
                    />
                  </div>
                  {error ? <p className={styles.error} id={`${id}-error`} role="alert">{error}</p> : field === "unitPrice" && <p className={styles.hint} id={`${id}-hint`}>Enter the unit price in Australian dollars.</p>}
                </div>
              );
            })}
          </div>
          <button type="button" className={ui.secondaryAction} aria-label={`Remove charge ${index + 1}`} onClick={() => setRows((current) => current.filter((item) => item.id !== row.id))}>Remove charge</button>
        </fieldset>
      ))}
      <button type="button" className={ui.secondaryAction} disabled={disabled} onClick={() => {
        const id = nextId.current++;
        setRows((current) => [...current, { id, values: { description: "", quantity: "1", unitPrice: "" }, errors: { description: undefined, quantity: undefined, unitPrice: undefined } }]);
      }}>Add charge</button>
    </section>
  );
}

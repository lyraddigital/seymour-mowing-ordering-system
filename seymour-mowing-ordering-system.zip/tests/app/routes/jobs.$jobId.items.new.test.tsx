import { env } from "cloudflare:workers";
import type { ComponentProps } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import {
  createMemoryRouter,
  RouterContextProvider,
  RouterProvider,
} from "react-router";
import { beforeEach, expect, it } from "vitest";

import { action, loader } from "../../../app/routes/jobs.$jobId.items.new";
import { currentUserContext } from "../../../app/server/auth/context/current-user-context";
import { runtimeContext } from "../../../app/server/auth/context/runtime-context";
import { createDb } from "../../../app/server/db/client/create-db.server";
import { customers } from "../../../app/server/db/schema/customers";
import { jobItems } from "../../../app/server/db/schema/job-items";
import { jobStatusHistory } from "../../../app/server/db/schema/job-status-history";
import { jobs } from "../../../app/server/db/schema/jobs";
import { users } from "../../../app/server/db/schema/users";
import { createJob } from "../../../app/server/features/jobs/services/create-job.server";
import AddJobItemPage from "../../../app/ui/features/jobs/pages/add-job-item-page/add-job-item-page";
import { internalUser } from "../../support/fixtures/internal-user";

const user = internalUser();

let context: RouterContextProvider;
let jobId: string;

function loaderArgs() {
  return {
    context,
    request: new Request(`https://example.test/jobs/${jobId}/items/new`),
    url: new URL(`https://example.test/jobs/${jobId}/items/new`),
    params: { jobId },
    pattern: "/jobs/:jobId/items/new",
  };
}

function actionArgs(body: URLSearchParams) {
  return {
    context,
    request: new Request(`https://example.test/jobs/${jobId}/items/new`, {
      method: "POST",
      body,
    }),
    url: new URL(`https://example.test/jobs/${jobId}/items/new`),
    params: { jobId },
    pattern: "/jobs/:jobId/items/new",
  };
}

function renderPage(props: ComponentProps<typeof AddJobItemPage>) {
  const router = createMemoryRouter(
    [
      {
        path: "/jobs/:jobId/items/new",
        element: <AddJobItemPage {...props} />,
      },
    ],
    {
      initialEntries: [`/jobs/${jobId}/items/new`],
    },
  );

  return renderToStaticMarkup(<RouterProvider router={router} />);
}

async function expectResponseStatus(promise: Promise<unknown>, status: number) {
  try {
    await promise;

    throw new Error(`Expected Response with status ${status}`);
  } catch (error) {
    expect(error).toBeInstanceOf(Response);
    expect((error as Response).status).toBe(status);
  }
}

beforeEach(async () => {
  context = new RouterContextProvider();

  context.set(currentUserContext, user);
  context.set(runtimeContext, {
    env,
    ctx: {} as ExecutionContext,
  });

  const db = createDb(env.DB);

  await db.delete(jobItems);
  await db.delete(jobStatusHistory);
  await db.delete(jobs);
  await db.delete(customers);
  await db.delete(users);

  await db.insert(users).values(user);

  await db.insert(customers).values({
    id: "customer",
    name: "John Smith",
    createdAt: 1,
    updatedAt: 1,
  });

  ({ id: jobId } = await createJob(env.DB, user, {
    customerId: "customer",
    name: "Front & Back Lawn Mow",
    description: "Mow lawns",
    scheduledDate: "2026-09-16",
  }));
});

it("loads the job", async () => {
  const result = await loader(loaderArgs());

  expect(result.job).toMatchObject({
    id: jobId,
    name: "Front & Back Lawn Mow",
    customerId: "customer",
    customerName: "John Smith",
  });
});

it("renders the add item workflow with job and customer context", async () => {
  const result = await loader(loaderArgs());

  const html = renderPage({
    job: result.job,
  });

  expect(html).toContain("Add job item");
  expect(html).toContain("Add work or a charge to Front &amp; Back Lawn Mow.");

  expect(html).toContain("Item details");

  expect(html).toContain("Front &amp; Back Lawn Mow");
  expect(html).toContain("John Smith");
  expect(html).toContain('href="/customers/customer"');

  expect(html).toContain('name="description"');
  expect(html).toContain('aria-describedby="description-hint"');

  expect(html).toContain('name="quantity"');
  expect(html).toMatch(/name="quantity"[^>]*value="1"/);
  expect(html).toContain('name="unitPrice"');
  expect(html).toContain('inputMode="decimal"');
  expect(html).toContain('aria-describedby="unitPrice-hint"');

  expect(html).toContain("Enter the charge in Australian dollars.");

  expect(html).toContain("Add item");
  expect(html).toContain("Cancel");
  expect(html).toContain(`href="/jobs/${jobId}"`);
});

it.each([
  ["45", 4500],
  ["45.00", 4500],
  ["45.5", 4550],
  ["0", 0],
  ["0.00", 0],
] as const)(
  "stores unitPrice %s as %i cents",
  async (unitPrice, expectedAmountCents) => {
    const response = await action(
      actionArgs(
        new URLSearchParams({
          quantity: "1",
          description: "Front lawn",
          unitPrice,
        }),
      ),
    );

    expect(response).toBeInstanceOf(Response);
    expect((response as Response).status).toBe(302);
    expect((response as Response).headers.get("Location")).toBe(
      `/jobs/${jobId}`,
    );

    expect(await createDb(env.DB).select().from(jobItems)).toEqual([
      expect.objectContaining({
        jobId,
        description: "Front lawn",
        quantity: 1,
        unitPriceCents: expectedAmountCents,
      }),
    ]);
  },
);

it.each(["", "abc", "1.234", "-1", "$45.00"])(
  "returns 400 for invalid unitPrice %j",
  async (unitPrice) => {
    const result = await action(
      actionArgs(
        new URLSearchParams({
          quantity: "1",
          description: "Front lawn",
          unitPrice,
        }),
      ),
    );

    expect(result).toMatchObject({
      init: {
        status: 400,
      },
      data: {
        values: {
          description: "Front lawn",
          unitPrice,
        },
        fieldErrors: {
          unitPriceCents: expect.any(String),
        },
      },
    });

    expect(await createDb(env.DB).select().from(jobItems)).toEqual([]);
  },
);

it("returns 400 for a blank description", async () => {
  const result = await action(
    actionArgs(
      new URLSearchParams({
        quantity: "1",
        description: " ",
        unitPrice: "45.00",
      }),
    ),
  );

  expect(result).toMatchObject({
    init: {
      status: 400,
    },
    data: {
      values: {
        description: " ",
        unitPrice: "45.00",
      },
      fieldErrors: {
        description: expect.any(String),
      },
    },
  });

  expect(await createDb(env.DB).select().from(jobItems)).toEqual([]);
});

it("renders validation errors while preserving submitted values", async () => {
  const result = await action(
    actionArgs(
      new URLSearchParams({
        quantity: "1",
        description: "Front lawn",
        unitPrice: "invalid",
      }),
    ),
  );

  if (result instanceof Response) {
    throw new Error("Expected validation data");
  }

  const html = renderPage({
    job: (await loader(loaderArgs())).job,
    values: result.data.values,
    fieldErrors: result.data.fieldErrors,
  });

  expect(html).toContain('value="Front lawn"');
  expect(html).toContain('value="invalid"');

  expect(html).toContain('aria-invalid="true"');
  expect(html).toContain('aria-describedby="unitPrice-error"');
  expect(html).toContain('id="unitPrice-error"');
  expect(html).toContain('role="alert"');
});

it.each(["completed", "cancelled"] as const)(
  "returns 409 when adding an item to a %s job",
  async (status) => {
    await createDb(env.DB)
      .insert(jobStatusHistory)
      .values({
        id: `status-${status}`,
        jobId,
        status,
        createdByUserId: user.id,
        createdAt: Date.now() + 1,
      });

    await expectResponseStatus(
      action(
        actionArgs(
          new URLSearchParams({
            quantity: "1",
            description: "Final charge",
            unitPrice: "25.00",
          }),
        ),
      ),
      409,
    );

    expect(await createDb(env.DB).select().from(jobItems)).toEqual([]);
  },
);

it("returns 404 for a missing job", async () => {
  jobId = "missing";

  await expectResponseStatus(loader(loaderArgs()), 404);
});

it("returns 404 when adding an item to a missing job", async () => {
  jobId = "missing";

  await expectResponseStatus(
    action(
      actionArgs(
        new URLSearchParams({
          quantity: "1",
          description: "Front lawn",
          unitPrice: "45.00",
        }),
      ),
    ),
    404,
  );
});

it("returns 403 without manage permission", async () => {
  context.set(currentUserContext, {
    ...user,
    role: "unknown" as "admin",
  });

  await expectResponseStatus(loader(loaderArgs()), 403);

  await expectResponseStatus(
    action(
      actionArgs(
        new URLSearchParams({
          quantity: "1",
          description: "Front lawn",
          unitPrice: "45.00",
        }),
      ),
    ),
    403,
  );
});

it("requires the authenticated user context", async () => {
  context = new RouterContextProvider();

  context.set(runtimeContext, {
    env,
    ctx: {} as ExecutionContext,
  });

  await expect(loader(loaderArgs())).rejects.toThrow();
});

it.each([
  "",
  " ",
  "0",
  "-1",
  "1.5",
  "NaN",
  "abc",
  "Infinity",
  "1e2",
  "0x10",
  "9007199254740992",
])("rejects and preserves invalid quantity %j", async (quantity) => {
  const before = await createDb(env.DB).select().from(jobItems);
  const result = await action(
    actionArgs(
      new URLSearchParams({
        description: "Green waste",
        quantity,
        unitPrice: "10.00",
      }),
    ),
  );
  if (result instanceof Response) throw new Error("Expected validation data");
  expect(result.init?.status).toBe(400);
  expect(result.data).toMatchObject({
    values: { quantity, unitPrice: "10.00" },
    fieldErrors: { quantity: expect.any(String) },
  });
  expect(await createDb(env.DB).select().from(jobItems)).toEqual(before);
  const html = renderPage({
    ...(await loader(loaderArgs())),
    values: result.data.values,
    fieldErrors: result.data.fieldErrors,
  });
  expect(html).toContain('id="quantity-error"');
  expect(html).toContain('aria-describedby="quantity-error"');
});
it("stores submitted quantity and unit price", async () => {
  const result = await action(
    actionArgs(
      new URLSearchParams({
        description: "Green waste",
        quantity: "3",
        unitPrice: "10.00",
      }),
    ),
  );
  expect(result).toBeInstanceOf(Response);
  expect(await createDb(env.DB).select().from(jobItems)).toEqual([
    expect.objectContaining({ quantity: 3, unitPriceCents: 1000 }),
  ]);
});

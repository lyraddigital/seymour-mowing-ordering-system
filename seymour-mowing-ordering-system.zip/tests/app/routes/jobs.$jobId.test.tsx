import { startJob } from "../../../app/server/features/jobs/services/start-job.server";
import { reopenJob } from "../../../app/server/features/jobs/services/reopen-job.server";
import { completeInvoiceJobs } from "../../support/fixtures/complete-invoice-jobs";
import { env } from "cloudflare:workers";
import { eq } from "drizzle-orm";
import { renderToStaticMarkup } from "react-dom/server";
import {
  createMemoryRouter,
  RouterContextProvider,
  RouterProvider,
} from "react-router";
import { beforeEach, expect, it } from "vitest";

import { loader } from "../../../app/routes/jobs.$jobId";
import { currentUserContext } from "../../../app/server/auth/context/current-user-context";
import { runtimeContext } from "../../../app/server/auth/context/runtime-context";
import { createDb } from "../../../app/server/db/client/create-db.server";
import { customers } from "../../../app/server/db/schema/customers";
import { invoiceItems } from "../../../app/server/db/schema/invoice-items";
import { invoiceJobs } from "../../../app/server/db/schema/invoice-jobs";
import { invoices } from "../../../app/server/db/schema/invoices";
import { jobItems } from "../../../app/server/db/schema/job-items";
import { jobStatusHistory } from "../../../app/server/db/schema/job-status-history";
import { jobs } from "../../../app/server/db/schema/jobs";
import { payments } from "../../../app/server/db/schema/payments";
import { users } from "../../../app/server/db/schema/users";
import { createDraftInvoice } from "../../../app/server/features/invoices/services/create-draft-invoice.server";
import { cancelJob } from "../../../app/server/features/jobs/services/cancel-job.server";
import { completeJob } from "../../../app/server/features/jobs/services/complete-job.server";
import { createJob } from "../../../app/server/features/jobs/services/create-job.server";
import JobPage from "../../../app/ui/features/jobs/pages/job-page/job-page";
import { internalUser } from "../../support/fixtures/internal-user";

const user = internalUser();

let context: RouterContextProvider;
let jobId: string;

function renderPage(props: Parameters<typeof JobPage>[0]) {
  const router = createMemoryRouter(
    [
      {
        path: "/jobs/:jobId",
        element: <JobPage {...props} />,
      },
    ],
    {
      initialEntries: [`/jobs/${props.job.id}`],
    },
  );

  return renderToStaticMarkup(<RouterProvider router={router} />);
}

function args(id = jobId) {
  return {
    context,
    request: new Request(`https://example.test/jobs/${id}`),
    url: new URL(`https://example.test/jobs/${id}`),
    params: {
      jobId: id,
    },
    pattern: "/jobs/:jobId",
  };
}

beforeEach(async () => {
  context = new RouterContextProvider();

  context.set(currentUserContext, user);
  context.set(runtimeContext, {
    env,
    ctx: {} as ExecutionContext,
  });

  const db = createDb(env.DB);

  await db.delete(payments);
  await db.delete(invoiceItems);
  await db.delete(invoiceJobs);
  await db.delete(invoices);
  await db.delete(jobItems);
  await db.delete(jobStatusHistory);
  await db.delete(jobs);
  await db.delete(customers);
  await db.delete(users);

  await db.insert(users).values(user);

  await db.insert(customers).values({
    id: "customer",
    name: "John Smith",
    createdAt: 1,
    updatedAt: 1,
  });

  jobId = (
    await createJob(env.DB, user, {
      name: "Front & Back Lawn Mow",
      customerId: "customer",
      description: "Mow lawns, edge paths and blow down.",
      scheduledDate: "2026-09-17",
    })
  ).id;
});

it("renders the job detail hierarchy for an administrator", async () => {
  const result = await loader(args());

  expect(result.canManage).toBe(true);
  expect(result.invoice).toBeNull();
  expect(result.canCreateInvoice).toBe(false);

  const html = renderPage(result);

  expect(html).toContain(
    '<h1 class="page-title">Front &amp; Back Lawn Mow</h1>',
  );

  expect(html).toContain("Scheduled");
  expect(html).toContain('href="/customers/customer"');
  expect(html).toContain("John Smith");
  expect(html).toContain("17 September 2026");
  expect(html).toContain("Mow lawns, edge paths and blow down.");

  expect(html).toContain('href="/jobs"');
  expect(html).toContain(`href="/jobs/${jobId}/edit"`);

  expect(html).toContain(`action="/jobs/${jobId}/start"`);
  expect(html).toContain(`action="/jobs/${jobId}/complete"`);
  expect(html).toContain("Start Job");
  expect(html).toContain("Complete Job");

  expect(html).toContain("Items");
  expect(html).toContain("No items have been added yet.");

  expect(html).not.toContain('id="job-invoice-heading"');
  expect(html).not.toContain("Create invoice");
  expect(html).toContain("Complete this job?");
  expect(html).toContain("Service price");
  expect(html).toContain('aria-label="Close"');
  expect(html).toContain("AUD");
  expect(html).toContain("Additional charges");
  expect(html).toContain("Continue");
  expect(html).toContain("Back");
  expect(html).toContain("<dialog");

  expect(html).toContain("Danger zone");
  expect(html).toContain("<summary>Cancel Job</summary>");
  expect(html).toContain(`action="/jobs/${jobId}/cancel"`);
  expect(html).toContain("Confirm cancellation");
});

it("shows the active invoice relationship instead of create invoice", async () => {
  await completeInvoiceJobs(user, [jobId]);
  const { id: invoiceId } = await createDraftInvoice(env.DB, user, {
    jobIds: [jobId],
  });

  const result = await loader(args());

  expect(result.invoice).toEqual({
    id: invoiceId,
    invoiceNumber: null,
    status: "draft",
  });
  expect(result.canCreateInvoice).toBe(false);

  const html = renderPage(result);

  expect(html).toContain("Invoice");
  expect(html).toContain("Draft invoice");
  expect(html).toContain("Draft");
  expect(html).toContain("This job is currently assigned to this invoice.");
  expect(html).toContain(`href="/invoices/${invoiceId}"`);
  expect(html).toContain("View invoice");

  expect(html).not.toContain(`href="/invoices/new?jobId=${jobId}"`);
  expect(html).not.toContain("Create invoice");
});

it("shows an invoice relationship to an operator but not invoice creation", async () => {
  await completeInvoiceJobs(user, [jobId]);
  const { id: invoiceId } = await createDraftInvoice(env.DB, user, {
    jobIds: [jobId],
  });

  context.set(currentUserContext, {
    ...user,
    role: "operator",
  });

  const result = await loader(args());

  expect(result.canManage).toBe(true);
  expect(result.canCreateInvoice).toBe(false);
  expect(result.invoice).toEqual({
    id: invoiceId,
    invoiceNumber: null,
    status: "draft",
  });

  const html = renderPage(result);

  expect(html).toContain("Draft invoice");
  expect(html).toContain(`href="/invoices/${invoiceId}"`);
  expect(html).not.toContain("Create invoice");
});

it("does not offer invoice creation to an operator", async () => {
  context.set(currentUserContext, {
    ...user,
    role: "operator",
  });

  const result = await loader(args());

  expect(result.canManage).toBe(true);
  expect(result.canCreateInvoice).toBe(false);
  expect(result.invoice).toBeNull();

  const html = renderPage(result);

  expect(html).toContain("Start Job");
  expect(html).toContain("Complete Job");
  expect(html).toContain("Danger zone");
  expect(html).toContain("Cancel Job");

  expect(html).not.toContain("Create invoice");
});

it.each([
  ["completed", completeJob],
  ["cancelled", cancelJob],
] as const)(
  "shows a %s job without edit, lifecycle controls or danger zone",
  async (status, operation) => {
    if (operation === completeJob) {
      await createDb(env.DB)
        .update(jobs)
        .set({ servicePriceCents: 10_000 })
        .where(eq(jobs.id, jobId));
    }

    await operation(env.DB, user, jobId, 10_000);

    const result = await loader(args());
    const html = renderPage(result);

    expect(html).toContain(status === "completed" ? "Completed" : "Cancelled");

    expect(html).not.toContain(`href="/jobs/${jobId}/edit"`);

    expect(html).not.toContain(`action="/jobs/${jobId}/start"`);
    expect(html).not.toContain(`action="/jobs/${jobId}/complete"`);
    expect(html).not.toContain(`action="/jobs/${jobId}/cancel"`);

    expect(html).not.toContain("Start Job");
    expect(html).not.toContain("Complete Job");
    expect(html).not.toContain("Cancel Job");
    expect(html).not.toContain("Danger zone");

    if (status === "completed") {
      expect(html).toContain(`action="/jobs/${jobId}/reopen"`);
      expect(html).toContain("Reopen job");
      expect(html).toContain('id="job-invoice-heading"');
      expect(html).toContain("Create invoice");
    } else {
      expect(html).not.toContain(`action="/jobs/${jobId}/reopen"`);
      expect(html).not.toContain("Reopen job");
      expect(html).not.toContain('id="job-invoice-heading"');
    }
  },
);

it("hides management controls when job management is not allowed", async () => {
  const result = await loader(args());

  const html = renderPage({
    ...result,
    canManage: false,
    canCreateInvoice: false,
  });

  expect(html).not.toContain(`href="/jobs/${jobId}/edit"`);
  expect(html).not.toContain(`action="/jobs/${jobId}/start"`);
  expect(html).not.toContain(`action="/jobs/${jobId}/complete"`);
  expect(html).not.toContain(`action="/jobs/${jobId}/cancel"`);

  expect(html).not.toContain("Start Job");
  expect(html).not.toContain("Complete Job");
  expect(html).not.toContain("Cancel Job");
  expect(html).not.toContain("Danger zone");
  expect(html).not.toContain("Create invoice");
});

it("returns 404 for an unknown job", async () => {
  await expect(loader(args("missing"))).rejects.toMatchObject({
    status: 404,
  });
});

it("requires read permission", async () => {
  context.set(currentUserContext, {
    ...user,
    role: "unknown" as "admin",
  });

  await expect(loader(args())).rejects.toMatchObject({
    status: 403,
  });
});

it("requires the authenticated user context", async () => {
  context = new RouterContextProvider();

  context.set(runtimeContext, {
    env,
    ctx: {} as ExecutionContext,
  });

  await expect(loader(args())).rejects.toThrow();
});

it("hides invoices for in-progress and reopened jobs", async () => {
  await startJob(env.DB, user, jobId);
  expect(renderPage(await loader(args()))).not.toContain(
    'id="job-invoice-heading"',
  );
  await completeJob(env.DB, user, jobId, 12345);
  await reopenJob(env.DB, user, jobId);
  expect(renderPage(await loader(args()))).not.toContain(
    'id="job-invoice-heading"',
  );
});

it("shows the charge subtotal separately from the completed Job total", async () => {
  await createDb(env.DB).insert(jobItems).values({
    id: "charge",
    jobId,
    description: "Green waste",
    quantity: 3,
    unitPriceCents: 1000,
    createdAt: 1,
    updatedAt: 1,
  });
  await completeJob(env.DB, user, jobId, 10000);
  const result = await loader(args());
  expect(result.additionalChargesCents).toBe(3000);
  const html = renderPage(result);
  expect(html).toContain("3 × $10.00");
  expect(html).toContain("Additional charges subtotal");
  expect(html).toContain("$30.00");
  expect(html).toContain("Service price");
  expect(html).toContain("$100.00");
  expect(html).toContain("Job total");
  expect(html).toContain("$130.00");
});

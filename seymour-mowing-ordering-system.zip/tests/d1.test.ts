import { Miniflare, convertV4MiniflareOptions } from "miniflare";
import { sql } from "drizzle-orm";
import { expect, it } from "vitest";
import { createDb } from "../app/db/client.server";

it("queries an isolated local D1 through Drizzle without domain tables", async () => {
  const runtime = new Miniflare(
    convertV4MiniflareOptions({
      modules: true,
      script: "export default { fetch() { return new Response('test'); } };",
      compatibilityDate: "2026-09-11",
      d1Databases: ["DB"],
    }),
  );
  try {
    const binding = await runtime.getD1Database("DB");
    const db = createDb(binding);
    expect(await db.get<{ value: number }>(sql`select 1 as value`)).toEqual({
      value: 1,
    });
    const tables = await db.all<{ name: string }>(
      sql`select name from sqlite_master where type = 'table' and name not like 'sqlite_%' and name not like '_cf_%'`,
    );
    expect(tables).toEqual([]);
  } finally {
    await runtime.dispose();
  }
});

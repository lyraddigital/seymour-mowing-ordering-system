# Seymour engineering rules

- React Router v8 Framework Mode with SSR.
- Cloudflare Workers runtime.
- D1 is the application database.
- Drizzle is the SQL/schema layer.
- Prefer loaders/actions and HTML forms over client-side API calls.
- Do not introduce a separate REST API unless required.
- Client-side React is reserved for genuine interactivity.
- Monetary values are integer cents.
- All customer-facing prices include GST.
- Issued invoices and invoice items are immutable.
- Draft invoices may be deleted.
- Issued invoices are voided, never deleted.
- Invoice items are billing records, not job items.
- Customers are archived, never deleted.
- Do not implement Reports, Settings, Expenses, Suppliers or cost pricing.

# Seymour architectural constraints

- Use React Router v8 **Framework Mode**, TypeScript in strict mode, and SSR on Cloudflare Workers. Preserve the official C3 entry points: `app/root.tsx`, `app/routes.ts`, `workers/app.ts`, and the React Router and Cloudflare Vite plugins. Do not introduce a Node server, Pages adapter, SPA-only router, or RSC without an explicit architectural decision.
- Define routes in `app/routes.ts`. Use generated `Route.*` types for route exports. Prefer server loaders/actions for reads and writes; keep document structure and error handling in the root route.
- Use Cloudflare bindings for infrastructure access. The v8 template uses `env` from `cloudflare:workers` in server code. Keep secrets and database code in `.server.ts` modules or server-only directories; never serialize bindings or secrets to the browser.
- D1 is the database and Drizzle is the query layer. Create clients per request with `createDb(env.DB)` from `app/db/client.server.ts`. Do not keep mutable request state or database clients in global singletons.
- The scaffold intentionally contains no business-domain tables, seed data, users, credentials, authentication implementation, or fake login controls. Add domain schema only for an explicitly scoped feature.
- Keep schema declarations in `app/db/schema.ts`, generate SQL with Drizzle Kit, review and commit migrations under `drizzle/migrations`, and apply them with Wrangler. Never run migrations in request handlers. Avoid direct schema pushes to shared environments.
- The default Wrangler environment is local. Staging and production have separate Workers and D1 databases. Repeat non-inherited bindings and variables in each environment. Select environments using `CLOUDFLARE_ENV` at build time; deploy the resulting flattened config without trying to retarget it with `--env`.
- Keep Wrangler as the source of truth. Generate `worker-configuration.d.ts` with `npm run cf-typegen`; never hand-edit generated bindings or `.react-router/types`. Keep compatibility flags/date intentional and logs/traces enabled.
- Keep local secrets in ignored `.dev.vars` files and deployed secrets in Cloudflare secrets. Never commit tokens or real secret values. Placeholder remote D1 IDs must be replaced with verified environment-specific IDs before deployment.
- Preserve an accessible, responsive Seymour UI. Use semantic HTML and CSS, and keep the initial login page an empty shell until authentication requirements are supplied.
- Use npm and commit `package-lock.json`. Run `npm run check` and the relevant Workers build before completing changes. Use Vitest for behavioral tests; use a real local D1 emulator for database integration tests. Test fixtures must remain isolated from persisted development and remote databases.
- Do not edit generated build output, runtime types, dependency files, or local state. Keep changes focused on the requested feature.

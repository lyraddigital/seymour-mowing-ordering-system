# Seymour Mowing Ordering System — Agent Instructions

## Purpose

This repository contains the Seymour Mowing Ordering System.

When making changes:

- Preserve the existing architecture.

- Prefer small, reviewable changes.

- Follow existing patterns before introducing new ones.

- Avoid unrelated refactors.

- Keep implementation explicit, readable, and boring.

- Use pragmatic SOLID principles.

- Avoid abstraction for abstraction's sake.

- Read this file before making changes.

If existing code conflicts with assumptions in a task prompt, inspect the repository and follow established project conventions unless the task explicitly requires changing them.

---

# Technology Stack

The application uses:

- Cloudflare Workers

- React Router Framework Mode with SSR

- TypeScript with strict mode

- Cloudflare D1

- Drizzle ORM

- Cloudflare Access

- Google as the sole Cloudflare Access identity provider

- Vitest and the project's existing test infrastructure

Staging and production are deployed independently.

Production deployment requires approval.

Do not introduce infrastructure, frameworks, packages, or architectural layers unless clearly required by the task.

---

# General Engineering Principles

Prefer:

- simple code

- explicit dependencies

- small functions with clear responsibilities

- feature-local code

- domain-specific names

- predictable control flow

- narrow interfaces

- server-side validation

- database constraints where appropriate

- transactions where multiple writes form one business operation

Avoid:

- speculative abstractions

- generic repository layers without demonstrated need

- service locators

- global dependency containers

- unnecessary inheritance

- generic CRUD frameworks

- premature state machines

- excessive indirection

- unnecessary wrapper functions

- unrelated cleanup while implementing a feature

A small amount of duplication is preferable to premature abstraction.

Refactor only when required by the task or when a small local refactor is necessary to implement requested behaviour cleanly.

---

# Application Architecture

## Routes

React Router route modules live under:

```text

app/routes/

```

Routes are thin adapters/controllers.

A route may:

- authenticate the request

- authorize the user

- parse route parameters

- parse submitted form data

- call server feature functions

- map known server results to HTTP responses

- redirect

- provide loader/action data to presentation components

Routes should not contain substantial business logic.

Do not place database queries directly in route modules when the logic belongs to a server feature.

Do not turn route modules into large page components.

Where one route action represents one specific business operation, prefer a dedicated route/action rather than a generic action that dispatches based on a value supplied by the client.

For example, prefer:

```text

POST /jobs/:jobId/start

POST /jobs/:jobId/complete

POST /jobs/:jobId/cancel

```

over a single generic status route accepting a client-supplied target status.

---

# Server Features

Server-side feature logic lives under:

```text

app/server/features/<feature>/

```

Examples:

```text

app/server/features/customers/

app/server/features/jobs/

```

Feature code should use domain-specific files.

Prefer one meaningful concept per file.

Good examples:

```text

create-job.ts

update-job.ts

start-job.ts

complete-job.ts

cancel-job.ts

create-job-input.ts

update-job-input.ts

validate-create-job.ts

validate-update-job.ts

job-status.ts

get-active-jobs.ts

get-job-history.ts

archive-customer.ts

```

Avoid catch-all files such as:

```text

types.ts

utils.ts

helpers.ts

models.ts

services.ts

common.ts

```

unless the contents genuinely represent one cohesive concept and the repository already uses that convention.

Do not introduce classes merely to create "services".

Functions are preferred when they clearly express the operation.

---

# Queries

Queries should live near the server feature that owns the read behaviour.

For example:

```text

app/server/features/jobs/queries/get-active-jobs.ts

app/server/features/jobs/queries/get-job-history.ts

```

Queries should return data shaped appropriately for their caller.

Do not force routes or UI code to reconstruct domain state from raw database rows when the server query can express it clearly.

Avoid generic repository abstractions.

Cross-feature reads are acceptable when simple and intentional.

Do not create a generic data-access layer solely to prevent one feature from reading data owned by another feature.

Reuse an existing query when it already expresses the required behaviour cleanly.

---

# UI Architecture

Feature UI lives under:

```text

app/ui/features/<feature>/

```

Feature UI is separated into:

```text

pages/

components/

```

## Pages

Route-level page components belong under:

```text

app/ui/features/<feature>/pages/

```

Route-level page components must not be placed under `components/`.

Meaningful pages should own their own folder.

Example:

```text

app/ui/features/jobs/pages/jobs-page/

├── jobs-page.tsx

└── jobs-page.module.css

```

## Components

Reusable or meaningful feature components belong under:

```text

app/ui/features/<feature>/components/

```

Meaningful components should normally own their own folder.

Do not extract trivial components merely to reduce line count.

Create a component when it represents a meaningful UI concept, has reusable behaviour, or materially improves readability.

If an active Job row/card gains several meaningful actions and the existing list component becomes unwieldy, extracting a Job list item component is acceptable.

Do not force such extraction prematurely.

---

# Component Props

Component prop types should normally be defined in the same file as the component that consumes them.

Example:

```tsx
interface JobListProps {
  jobs: JobListItem[];
}

export function JobList({ jobs }: JobListProps) {
  // ...
}
```

Do not create a separate file solely for a component's props.

A type should have its own file only when it represents a meaningful shared or domain concept independent of one component.

---

# CSS

Use CSS Modules following existing project conventions.

CSS should be co-located with the page, component, or layout that owns it.

Example:

```text

job-list.tsx

job-list.module.css

```

Avoid feature-wide CSS dumping grounds.

Do not move unrelated styles while implementing a feature.

Follow the established project UX/design direction before inventing new page-specific patterns.

When `UX-DESIGN.md` is present in the repository, treat it as the visual and interaction source of truth for UI work. Preserve domain behaviour while migrating older screens onto those conventions.

---

# Types

Use TypeScript strict mode correctly.

Do not weaken types to make implementation easier.

Avoid `any` unless interoperability genuinely requires it and use is narrowly contained.

Prefer domain-specific types with meaningful names.

Do not create catch-all `types.ts` files.

Types used only by one component should usually remain with that component.

Types representing a meaningful server/domain concept may have their own file.

Do not duplicate a type if Drizzle or another authoritative project source already provides the appropriate type cleanly.

---

# Validation

All mutation inputs must be validated on the server.

Client-side validation may improve UX but is not a substitute for server-side validation.

Validation behaviour should be explicit and testable.

Do not trust:

- form data

- route parameters

- foreign-key identifiers supplied by the browser

- status values supplied by the browser

- return destinations supplied by the browser

- user role information supplied by the browser

Business invariants must be enforced on the server.

The server should determine the resulting status for explicit business actions such as starting, completing, or cancelling a Job.

Do not accept arbitrary target status values from the client for those operations.

If a browser-provided return destination is supported, it must be restricted to known safe application destinations rather than treated as an arbitrary redirect URL.

---

# Authentication and Authorization

Cloudflare Access provides authentication using Google as the sole identity provider.

Application users are stored internally in D1.

Internal users currently have:

- admin

- operator

roles.

Follow existing authentication and authorization helpers and patterns.

Do not duplicate Access parsing or authorization logic when established helpers already exist.

All protected loaders and actions must enforce appropriate authentication and authorization server-side.

Do not rely on hiding UI controls as authorization.

---

# Database and Drizzle

Use existing D1 and Drizzle conventions.

Before adding schema code:

- inspect the existing schema layout

- follow the existing identifier strategy

- follow existing timestamp conventions

- follow existing foreign-key conventions

- follow existing migration conventions

Do not reorganize the database layer as part of an unrelated feature.

Do not manually choose a migration numbering scheme that conflicts with the project's existing Drizzle workflow.

Use database constraints where they reinforce meaningful invariants.

Add indexes where required by known query patterns, not speculatively.

---

# Transactions

Use a transaction when multiple writes together represent one business operation.

The operation should either succeed completely or leave the database unchanged.

Do not leave partially-created domain state.

For example, creating a Job and creating its initial Job status-history row are one operation and must be atomic.

---

# Customers Domain Rules

Customers are never hard-deleted.

Customers may be:

- active

- archived

Archived Customers may later be restored.

Current Customer operations include:

- active Customer list

- create Customer

- Customer detail

- edit Customer

- archive Customer

- archived Customer list

- restore Customer

New behaviour must preserve these semantics.

Do not introduce hard-delete Customer behaviour.

## Customer Address State

The current business operates in Victoria. Customer create/edit forms must not expose State as an editable field.

Persist `state = "VIC"` server-side for Customer address create/update operations. Do not rely on a hidden browser-submitted field for this invariant. Keep the database column for future flexibility and continue displaying `VIC` in formatted addresses where appropriate.

---

# Dashboard UX Rules

The Dashboard is a financial and operational attention screen, not an entity-count dashboard.

Follow `UX-DESIGN.md` and these reference images:

```text
docs/ux/dashboard-populated-reference.png
docs/ux/dashboard-empty-reference.png
```

The written rules below are authoritative where a reference image contains an older incidental detail.

## Dashboard primary metrics

Render these four primary metrics in this order:

1. Outstanding balance
2. Overdue balance
3. Invoices overdue
4. Payments received this month

Do not use:

- Active Customers as a primary Dashboard metric
- Customers overdue as a primary Dashboard metric
- generic entity counts as primary Dashboard metrics

`Invoices overdue` is an Invoice count, not a Customer count.

## Dashboard desktop composition

Below the four metric cards, preserve this layout:

- large `Needs attention` section on the left
- `Partially paid / unpaid invoices` at upper right
- `Recent payments` below it at lower right
- full-width `Today's jobs` section across the bottom

Do not rearrange the Dashboard when a section is empty. Populated and empty states must use the same overall geometry.

## Needs attention

This section is for overdue Invoices requiring action.

When populated, show a compact table/list with:

- Customer
- Invoice
- Due date
- Days overdue
- Balance

When empty, keep the section visible and show:

- title: `All caught up!`
- supporting text: `There are no invoices that need attention right now.`

## Partially paid / unpaid invoices

When populated, show:

- Customer
- Invoice
- payment state/status
- Balance

When empty, keep the section visible and show:

- title: `No unpaid invoices`
- supporting text: `All invoices are paid in full. Great work!`

## Recent payments

When populated, show recent Payments with:

- Date
- Customer
- Invoice
- Amount

When there are no recent Payments, the section must be empty. Do not leave sample/payment rows visible.

Empty copy:

- title: `No recent payments`
- supporting text: `Payments you receive will appear here.`

## Today's jobs

This is the full-width lower operational section.

When populated, follow the approved reference and summarise today's work using the existing Job lifecycle/status data.

When empty, keep the section visible and show:

- title: `No jobs scheduled today`
- supporting text: `Enjoy the day! New jobs will appear here when they're scheduled.`

## Dashboard shell

Preserve the accepted Seymour shell and existing placeholder logo/image asset for this phase.

Do not:

- render `LOGO PLACEHOLDER` as text
- swap in the final company logo in this task
- add Settings
- add Log out
- add a login/user block or account menu in the top-right of the Dashboard

Do not change authentication behaviour.

## Dashboard data

Dashboard values are derived. Do not add stored Dashboard totals.

- Outstanding balance derives from remaining balances on payable issued Invoices.
- Payments received this month sums active/non-voided Payments whose `paymentDate` falls in the current Melbourne calendar month.
- Overdue balance and Invoices overdue require an authoritative Invoice due-date rule.
- Recent Payments must follow existing Payment history semantics.
- Today's Jobs must use the existing Job lifecycle/status source of truth.

Do not fabricate overdue values. If authoritative Invoice due-date support does not exist, do not silently present `$0.00`, `0 invoices`, or fake overdue rows as real production data. Report the missing prerequisite clearly.

## Dashboard styling

Reuse the shared Seymour UX system.

Use:

- deep forest sidebar
- warm off-white workspace
- white/light cards and tables
- lawn-green accents
- dark green primary text
- restrained red/amber for attention states
- consistent icons, spacing, borders, radii, shadows, and table treatment

Do not create a second dashboard-only design system.

Each empty state should use the same section container as its populated state, with a centred icon, clear title, and short supporting sentence.

Do not add a graph/cash-flow chart to this Dashboard design.

---

# Jobs Domain Rules

Jobs preserve status history.

Do not model Job status solely as a mutable field whose previous values are discarded.

Job status-history records are the authoritative history of Job state.

The current Job status is determined from the latest applicable status-history record.

Do not introduce both:

```text

jobs.status

```

and:

```text

job_status_history

```

as competing sources of truth.

Current Job statuses are:

```text

scheduled

in_progress

completed

cancelled

```

Creating a Job:

- requires an active Customer

- creates the Job

- creates an initial `scheduled` status-history entry

- records the responsible internal Seymour user

- performs Job creation and initial history creation atomically

A Job must never be successfully created without its initial status-history record.

---

# Job Naming and Description

Jobs have a required human-readable name.

The Job name is distinct from the Job description.

Example:

```text

Name:

Front & Back Lawn Mow

Description:

Mow front and back lawns, edge driveway and blow clippings from paths.

```

The Job is the primary entity in Jobs UI.

The Job name should normally be the focal identifier and link to the Job detail page.

The Customer remains important contextual information and may link to the Customer record, but should not replace the Job as the primary UI concept.

Job name and description are descriptive metadata.

They may be edited only while the Job is scheduled or in progress. Completed and cancelled Jobs are locked. Reopen an eligible completed Job before making corrections.

Editing Job name or description must not create or modify Job status-history rows.

---

# Job Customer Immutability

The Customer associated with a Job is set when the Job is created and is immutable afterwards.

Do not provide a general edit operation for:

```text

customer_id

```

Do not include `customerId` in Job update input types or edit forms.

Do not allow a browser-submitted Customer id to alter an existing Job's Customer.

If a Job was created for the wrong Customer, the required correction workflow is:

```text

1. Cancel the incorrect Job.

2. Create a new Job for the correct Customer.

```

This is intentional.

Do not introduce a "Change Customer", "Reassign Customer", or equivalent operation unless explicitly requested by a later product decision.

The Customer relationship is considered part of the Job's identity and historical integrity.

---

# Scheduled Date Editing

A Job's scheduled date may be changed only while the authoritative current status is:

```text

scheduled

```

Once the Job leaves the scheduled phase, its scheduled date becomes immutable.

Therefore:

```text

scheduled:

  scheduled date editable

in_progress:

  scheduled date read-only

completed:

  scheduled date read-only

cancelled:

  scheduled date read-only

```

This rule must be enforced server-side.

Do not rely solely on disabling or hiding the field in the UI.

When updating an in-progress Job, name and description may still be changed, but the scheduled date must remain unchanged. Completed and cancelled Jobs reject ordinary edits.

If the edit form includes the existing scheduled date as a submitted value, do not reject an otherwise valid metadata edit merely because the field is present.

For an in-progress Job, reject a scheduled-date change but allow an unchanged submitted date.

Prefer making the field disabled or read-only in the UI when the Job is not scheduled, while still enforcing the invariant on the server.

Editing a scheduled date does not itself create a Job status-history record.

---

# Job Edit Rules

The current Job edit rules are:

```text

Field            Scheduled     In Progress     Completed     Cancelled

name             editable      editable        read-only      read-only

description      editable      editable        read-only      read-only

scheduled date   editable      read-only       read-only     read-only

customer         immutable     immutable       immutable     immutable

status           lifecycle     lifecycle       lifecycle     lifecycle

```

Status is never changed through the normal Job edit form.

Status changes occur only through explicit lifecycle operations.

The Job edit operation should only accept fields it is allowed to modify.

Do not create a broad update DTO that includes immutable or lifecycle-managed fields.

---

# Job Status Transitions

Current legal transitions are:

```text

scheduled -> in_progress

scheduled -> completed

scheduled -> cancelled

in_progress -> completed

in_progress -> cancelled

```

The following are not currently valid:

```text

in_progress -> scheduled

in_progress -> in_progress

completed -> scheduled

completed -> completed

completed -> cancelled

cancelled -> scheduled

cancelled -> in_progress

cancelled -> completed

cancelled -> cancelled

```

A completed Job may be reopened to `in_progress` only if it has no active invoice allocation. Reopening appends status history and retains the service price and all additional charges. Cancelled Jobs cannot be reopened.

There is currently no transition from `in_progress` back to `scheduled`.

A scheduled Job may be completed directly without first moving to `in_progress`.

This is intentional.

Starting, completing, cancelling, or reopening a Job must append a new status-history row.

Do not mutate or delete previous status-history records.

Each new status-history row must record the internal Seymour user responsible for the transition.

Transition validity must be enforced server-side using the authoritative current status.

Do not rely on the UI hiding buttons to prevent invalid transitions.

Prefer explicit business operations such as:

```text

startJob

completeJob

cancelJob

```

over generic status-setting APIs.

Do not introduce a generic workflow engine or state-machine abstraction unless future requirements demonstrate a real need.

---

# Job Billing Finalisation

Operational editing and billing finalisation are separate concerns. Ordinary Job editing never accepts or changes `servicePriceCents`.

Completion supplies a required non-negative integer-cent service price and persists it atomically with the completed status-history entry. Completion finalises and locks the billable Job state. The UI first warns about finalisation, then reviews the service price, existing additional charges, and derived total.

Reopening retains billing data, returns the Job to in-progress, and enables corrections before completing again. Jobs allocated to an active invoice cannot be reopened.

Only completed Jobs are invoiceable and expose invoice actions or relationships in the Job UI. Domain services enforce lifecycle invariants; UI visibility is not a security or domain boundary.

Invoice snapshots remain independent of subsequent Job changes. Do not implicitly refresh snapshot lines or completion dates when a Job is corrected or its lifecycle later changes.

---

# Jobs Workspace Status Views

Jobs are browsed in one `/jobs` workspace by authoritative lifecycle status:

```text

scheduled

in_progress

completed

cancelled

```

The selected status is represented by the `status` query parameter. Status-based collection filtering belongs in the server/query layer, using the latest applicable status-history record.

Job lifecycle status and Invoice allocation are separate concepts. Do not introduce `invoiced` as a Job lifecycle status or change a completed Job's status when it is allocated to an Invoice.

Completed Job views may show active Invoice-allocation information. They must continue to include both Jobs ready to invoice and Jobs already allocated to an Invoice.

Completed and cancelled Jobs remain normal Job records and continue to link to the shared Job detail page.

---

# Active Jobs Operational Actions

The active Jobs list is an operational screen, not merely a navigation index.

Common lifecycle actions should be available directly against active Jobs where appropriate.

For a Job whose current status is:

```text

scheduled

```

the active Jobs UI may expose:

```text

Start Job

Complete Job

Cancel Job

```

For a Job whose current status is:

```text

in_progress

```

the active Jobs UI may expose:

```text

Complete Job

Cancel Job

```

These actions may also remain available on the Job detail page.

Providing actions on the active list does not replace the Job detail page.

The same server-side transition operations and invariants must be used regardless of whether an action is initiated from the active Jobs list or Job detail page.

Do not duplicate transition business logic in UI components or routes.

The UI may decide which controls to show based on current status, but the server remains authoritative.

---

# Lifecycle Action Routes

Prefer one dedicated route/action per Job lifecycle operation.

Current operations are conceptually:

```text

POST /jobs/:jobId/start

POST /jobs/:jobId/complete

POST /jobs/:jobId/cancel

```

Do not replace these with a generic status endpoint controlled by a client-supplied status value.

Lifecycle routes should remain thin.

Their responsibilities are typically:

- authenticate

- authorize

- validate/read Job id

- call the relevant domain operation

- map known domain errors to the established response pattern

- redirect to the appropriate UI destination

Business transition rules belong in the server feature, not the route.

---

# Redirect Behaviour for Shared Actions

Lifecycle actions may be initiated from more than one UI surface, such as:

```text

/jobs

/jobs/:jobId

```

Do not put UI navigation concerns into `startJob`, `completeJob`, or `cancelJob`.

The route/controller layer owns redirect behaviour.

If a return destination is supplied by the client, it must be constrained to known safe application destinations.

Do not implement an open redirect using arbitrary client-provided URLs.

A small explicit destination value or route-specific behaviour is preferable to a generic redirect mechanism.

---

# Job Item Domain Rules

Job Items represent work performed or charges recorded against a Job.

Job Items are operational Job data.

They are distinct from Invoice Items.

Current Job Item fields are:

```text
description
amountCents
```

Money must be stored as integer cents.

Do not store Job Item monetary values as floating-point dollars.

A Job Item amount may be zero.

Negative Job Item amounts are not currently supported.

Do not introduce discounts or negative line items without an explicit later product decision.

A Job may have zero or more Job Items.

The Job total is derived from its service price and additional charges (Job Items).

Do not introduce a mutable stored Job-total field as a separate source of truth.

The current Job total is:

```text
servicePriceCents + sum(job_items.amount_cents)
```

Job Items may currently be:

- added
- edited
- removed

Additional charges may be created, edited, or removed only while the Job is scheduled or in progress. Completed and cancelled Jobs reject all charge mutations server-side. Charges remain editable through the normal Job UI before completion; the completion dialog is a final review.

Do not introduce additional Job statuses such as:

```text
priced
ready_for_invoice
```

unless explicitly required by a later product decision.

Job Item mutations must require the existing Job management permission.

Authorization must be enforced server-side.

Do not rely on hiding Job Item controls in the UI as authorization.

When addressing a Job Item through a nested route, both:

```text
jobId
itemId
```

must identify the same stored Job Item.

Do not allow a Job Item belonging to one Job to be read, updated, or removed through another Job's route.

Current Job Item routes are conceptually:

```text
GET/POST /jobs/:jobId/items/new
GET/POST /jobs/:jobId/items/:itemId/edit
POST     /jobs/:jobId/items/:itemId/delete
```

Prefer explicit operations such as:

```text
createJobItem
updateJobItem
deleteJobItem
```

rather than a generic Job Item mutation API.

Removing a Job Item currently performs a real deletion.

This is intentional for the current Job Item model because Job Items remain mutable operational pricing data before invoicing establishes a financial snapshot.

This deletion rule does not apply to issued Invoice Items.

Invoice Items are separate records from Job Items.

Adding a completed Job to an Invoice snapshots its service line and additional charges into Invoice Items.

Issued Invoice Items must not remain mutable projections of Job Items.

Later changes to Job Items must not modify an already-issued Invoice or its Invoice Items.

Job Item behaviour should be covered by focused tests including:

- creation
- validation
- integer-cent storage
- zero-value items
- listing and ordering
- derived Job totals
- editing
- removal
- authorization
- nested Job/Item ownership
- behaviour across scheduled, in-progress, completed, and cancelled Jobs

---

# Invoice Domain Rules

Invoices are financial snapshots built from one or more Jobs.

Invoice Items are distinct records from Job Items.

Do not model Invoice Items as mutable projections of Job Items.

Changes to Job Items after they have been snapshotted must not automatically alter existing Invoice Items.

Each selected Job contributes exactly one service line with quantity `1`, using the Job name and final `servicePriceCents`. Each current Job Item contributes a separate additional-charge line. Until Job Items gain explicit quantity and unit-price fields, map each Job Item to quantity `1` with its `amountCents` as both unit price and amount.

Invoice Items store `description`, integer `quantity`, `unitPriceCents`, and `amountCents`. The database must enforce `amountCents = quantity * unitPriceCents`.

The Job completion timestamp used by an Invoice is snapshotted on the Invoice/Job association when the Job is allocated. Invoice rendering must not derive that date from later Job status history.

Money must be stored as integer cents.

Do not store Invoice monetary values as floating-point dollars.

Pricing is GST-inclusive.

The Invoice total is derived from its Invoice Items.

Do not introduce a mutable stored Invoice-total field as an independent source of truth.

The current Invoice total is conceptually:

```text
sum(invoice_items.amount_cents)
```

---

## Invoice Statuses and Lifecycle

Current Invoice statuses are:

```text
draft
issued
voided
```

A draft Invoice:

- has `invoiceNumber = null`
- has `issuedAt = null`
- may be edited
- may be deleted
- may change its selected Jobs
- may have its Invoice Items added, edited, or removed

An issued Invoice:

- has an allocated Invoice number
- has `issuedAt` populated
- is immutable
- must not be deleted
- may be voided

A voided Invoice:

- retains its Invoice number
- retains its original issue information
- retains its Invoice Items and historical Job associations
- is immutable
- must not be deleted

There is currently no operation to return an issued or voided Invoice to draft.

There is currently no general Invoice reopen operation.

Do not introduce arbitrary client-controlled Invoice status mutation.

Prefer explicit business operations such as:

```text
issueInvoice
voidInvoice
deleteDraftInvoice
```

Issued and voided Invoice data must remain historical financial records.

---

## Invoice Numbering

Draft Invoices do not have Invoice numbers.

An Invoice number is allocated only when a draft is successfully issued.

The current format is:

```text
INV-000001
INV-000002
INV-000003
```

Invoice numbers must never be reused.

Voiding an Invoice does not free or recycle its number.

Deleting a draft does not consume an Invoice number because drafts have no number.

Do not allocate Invoice numbers in the browser or trust a browser-submitted Invoice number.

Number allocation is a server-side concern.

---

## Multi-Job Invoices

An Invoice may contain one or more Jobs.

All Jobs on one Invoice must belong to the same Customer.

The Invoice Customer is derived from the selected Jobs.

Do not trust a browser-submitted `customerId` when creating or changing an Invoice's Job selection.

The server must validate that all selected Jobs exist and belong to one Customer.

The relationship between Invoices and Jobs is stored explicitly through `invoice_jobs`.

A Job may not belong to more than one active Invoice at the same time.

For this rule, active Invoice associations are those whose `invoice_jobs.released_at` is null.

Draft and issued Invoices hold active Job associations.

When an issued Invoice is voided, its historical `invoice_jobs` rows are preserved and their `releasedAt` value is populated.

A released Job may then be invoiced again.

Deleting a draft removes its `invoice_jobs` rows and releases those Jobs.

The database should reinforce the single-active-Invoice-per-Job invariant using the existing partial unique index on active `invoice_jobs` rows.

Do not weaken this invariant to make UI flows easier.

---

## Creating Draft Invoices

The primary creation flow is conceptually:

```text
/invoices/new
-> choose Customer in the UI
-> choose one or more eligible Jobs for that Customer
-> create draft
-> redirect to /invoices/:invoiceId
```

The Customer selector is a UI convenience only.

The mutation should submit selected Job ids and derive the Customer server-side.

A Job-detail shortcut may navigate to:

```text
/invoices/new?jobId=<jobId>
```

This preselects an eligible Job but does not bypass server validation.

Do not create an Invoice immediately from a Job-detail POST simply because the shortcut originates from a Job.

Only completed Jobs may be selected for invoice creation or added to a draft. Enforce the authoritative latest status when allocating the Job, including races with reopening.

When a draft Invoice is created, each selected Job's service and current Job Items are snapshotted into Invoice Items. The authoritative completed status, required service price, and completion timestamp must be validated server-side as part of the atomic allocation operation.

Each Invoice Item records its source Job using `jobId`.

Invoice Items intentionally do not currently store `jobItemId`.

---

## Editing a Draft Invoice's Job Selection

Only draft Invoices may change their selected Jobs.

Issued and voided Invoices must reject this operation server-side.

The Customer of an existing Invoice does not change during draft Job-selection editing.

Newly selected Jobs must belong to the existing Invoice Customer.

Jobs assigned to another active Invoice must be rejected.

When editing a draft's Job selection:

- Jobs that remain selected keep their existing Invoice Items unchanged.
- Removing a Job removes that Job's Invoice Items from the draft.
- Removing a Job removes that Invoice's active `invoice_jobs` association for the Job.
- A removed Job becomes available for another active Invoice.
- Adding a Job creates a new active `invoice_jobs` association.
- Adding a Job snapshots that Job's service line, current Job Items, and completion timestamp into Invoice-owned data.

Do not rebuild or refresh Invoice Items for Jobs that remain selected.

This preservation rule is important because draft Invoice Items may themselves be edited.

A no-op Job-selection update should not destroy or regenerate Invoice Items.

---

## Draft Invoice Item Rules

Invoice Items belong to an Invoice and carry Job context through `jobId`.

Current Invoice Item fields are conceptually:

```text
invoiceId
jobId
description
quantity
unitPriceCents
amountCents
```

`amountCents` must equal `quantity * unitPriceCents`. Invoice totals derive only from these snapshotted amounts, never from live Job pricing.

Invoice Items do not currently contain `jobItemId`.

A draft Invoice may have its Invoice Items:

- added
- edited
- removed

Issued and voided Invoice Items are immutable.

All Invoice Item mutations must enforce `invoices.manage` server-side.

For a nested Invoice Item route, both:

```text
invoiceId
itemId
```

must identify the same stored Invoice Item.

Do not allow an Invoice Item belonging to one Invoice to be edited or removed through another Invoice's route.

A newly added Invoice Item must belong to one of the Jobs currently selected on that draft Invoice.

Do not accept an arbitrary `jobId` that is not an active Job association for that Invoice.

For an existing Invoice Item, its `jobId` is source context and should remain immutable through normal Invoice Item editing.

Normal Invoice Item editing should change only fields it is allowed to modify, currently:

```text
description
amountCents
```

Invoice Item amounts may be zero.

Negative Invoice Item amounts are not currently supported.

Do not introduce discounts or negative Invoice Items without a later explicit product decision.

Removing an Invoice Item from a draft currently performs a real deletion.

That deletion rule applies only to mutable draft Invoice Items.

It must never be used to erase line items from issued or voided Invoices.

When a Job is removed from a draft Invoice, all Invoice Items carrying that Job's `jobId` are removed with it, including Invoice Items that were manually added or edited on the draft.

Current conceptual routes for draft Invoice Item maintenance are:

```text
GET/POST /invoices/:invoiceId/items/new
GET/POST /invoices/:invoiceId/items/:itemId/edit
POST     /invoices/:invoiceId/items/:itemId/delete
```

Prefer explicit operations such as:

```text
createInvoiceItem
updateInvoiceItem
deleteInvoiceItem
```

rather than a generic Invoice mutation endpoint.

---

## Invoice Queries and UI

The main Invoice list is:

```text
/invoices
```

Invoice creation is:

```text
/invoices/new
```

Invoice detail is:

```text
/invoices/:invoiceId
```

Draft Job-selection editing is:

```text
/invoices/:invoiceId/edit
```

Invoice detail should show:

- Invoice number or Draft label
- status
- Customer
- selected Jobs
- Invoice Items grouped by Job where useful
- derived total
- lifecycle actions appropriate to status and permission

Draft lifecycle controls may include:

```text
Issue invoice
Edit draft
Delete draft
```

Issued lifecycle controls may include:

```text
Void invoice
```

Voided Invoices have no mutation controls under the current rules.

Hiding controls in the UI is not authorization.

The server must independently enforce state and permission rules.

---

## Invoice Lifecycle Routes

Prefer dedicated action routes for lifecycle operations:

```text
POST /invoices/:invoiceId/issue
POST /invoices/:invoiceId/void
POST /invoices/:invoiceId/delete
```

Routes remain thin adapters.

Known domain errors should be mapped consistently to the project's existing HTTP response patterns, including:

- not found
- permission denied
- invalid state/conflict
- invalid Job selection
- active Invoice Job conflict

Do not duplicate lifecycle business rules inside route modules or UI components.

---

# Payment Domain Rules

A Payment belongs to exactly one Invoice.

An Invoice may have multiple Payments.

Payments are financial history. Once recorded, a Payment is not edited in place or hard-deleted.

Incorrect Payments are voided so the original record remains auditable.

For the current Payment slice, keep the model deliberately small. Conceptually a Payment contains:

```text
id
invoiceId
amountCents
paymentDate
voidedAt
createdAt
```

For v1, Payments represent bank transfers. Do not add a payment-method field yet.

Do not add transaction references, notes, allocations across multiple Invoices, refunds, or external payment-provider integration unless a later task explicitly requires them.

Money must be stored as integer cents.

A recorded Payment amount must be greater than zero.

Negative and zero-value Payments are not valid Payment records.

A new Payment may only be recorded against an issued Invoice.

Do not allow new Payments on draft or voided Invoices.

The server must enforce Invoice status; hiding controls in the UI is insufficient.

`paymentDate` is the calendar date the payment appears as received in the bank account. It is user-entered, stored as `YYYY-MM-DD`, and is the authoritative date for bank reconciliation and financial reporting.

`createdAt` is assigned server-side when the Payment is recorded in Seymour and remains audit metadata.

Do not allow a future `paymentDate`.

A Payment may be voided only once.

Voiding a Payment preserves:

- its id
- Invoice relationship
- original amount
- original payment date
- original creation information

Voiding populates `voidedAt`; it does not rewrite the original Payment amount.

Do not hard-delete Payment history.

An active Payment is a Payment whose `voidedAt` is null.

Only active Payments contribute to the amount paid.

The amount paid is conceptually:

```text
sum(payments.amount_cents where voided_at is null)
```

The Invoice balance is derived from the Invoice total and active Payments:

```text
balanceCents = invoiceTotalCents - activePaymentTotalCents
```

Do not introduce mutable stored `paid` or `balance` fields as independent sources of truth.

Overpayments are not allowed.

When recording a Payment, the server must reject any amount that would make active Payments exceed the current Invoice total.

The overpayment rule must be enforced in the server feature layer and should be implemented atomically enough that concurrent Payment creation cannot knowingly violate the invariant. Follow the repository's existing D1/Drizzle transaction or batch conventions rather than adding a new persistence abstraction.

Current Payment operations should be explicit, for example:

```text
recordPayment
voidPayment
```

Do not create a generic Payment mutation endpoint that accepts an arbitrary operation or status from the browser.

Current conceptual routes are:

```text
GET/POST /invoices/:invoiceId/payments/new
POST     /invoices/:invoiceId/payments/:paymentId/void
```

For nested Payment routes, both:

```text
invoiceId
paymentId
```

must identify the same stored Payment.

Do not allow a Payment belonging to one Invoice to be voided through another Invoice's route.

Payment mutations require the existing Invoice management permission unless the repository already defines a more specific Payment permission. Do not invent a new permission solely for this slice.

Invoice detail should display Payment history and derived totals. A manageable issued Invoice with remaining balance may expose a `Record payment` action. Active Payments may expose a `Void payment` action where permitted. Draft Invoices do not expose Payment mutation controls.

Do not change the existing Invoice-void lifecycle semantics as part of the first Payment slice unless required to make the implementation internally consistent. If an interaction between Invoice voiding and existing Payments is not already specified in code or tests, preserve current Invoice behaviour and call the limitation out rather than inventing broader accounting rules.

---

# Testing

Tests structurally mirror production code under:

```text

tests/app/

```

For example:

```text

app/server/features/jobs/update-job.ts

```

should normally have a corresponding test near:

```text

tests/app/server/features/jobs/update-job.test.ts

```

Follow existing route-test conventions for files under `app/routes/`.

Tests should focus on behaviour and business invariants.

Do not duplicate implementation details unnecessarily.

High-value tests include:

- validation boundaries

- authorization

- domain invariants

- immutable Customer relationship

- scheduled-date mutation rules

- metadata editing across Job statuses

- status-history behaviour

- legal and illegal status transitions

- active/history filtering based on current status

- actions exposed for the correct active states

- predictable ordering

- failure cases that could otherwise create inconsistent state

Avoid broad snapshot tests when focused behavioural assertions are clearer.

For Job editing specifically, test at minimum:

- scheduled Job name can be changed

- scheduled Job description can be changed

- scheduled Job date can be changed

- in-progress Job name can be changed

- in-progress Job description can be changed

- in-progress Job date cannot be changed

- completed Job name cannot be changed

- completed Job description cannot be changed

- completed Job date cannot be changed

- cancelled Job name cannot be changed

- cancelled Job description cannot be changed

- cancelled Job date cannot be changed

- Customer cannot be changed through the update operation

- editing metadata does not alter status history

---

## Invoice Testing

Invoice behaviour should be covered with focused tests for:

- draft creation from one Job
- draft creation from multiple same-Customer Jobs
- mixed-Customer selection rejection
- missing and duplicate Job ids
- active-Invoice Job conflicts
- Invoice Item snapshot creation
- derived totals
- draft numbering remaining null
- sequential number allocation on issue
- number preservation on void
- issued Invoice immutability
- voided Invoice immutability
- draft deletion
- Job release after void
- Job release after draft deletion
- Job-detail Invoice shortcut eligibility
- draft Job-selection add/remove behaviour
- preservation of Invoice Items for retained Jobs
- snapshotting of current Job Items only for newly-added Jobs
- removal of Invoice Items when their Job is removed from a draft
- draft Invoice Item add/edit/remove
- Invoice Item amount validation including zero and negative values
- nested Invoice/Item ownership
- Invoice Item Job membership validation
- authorization for Invoice reads and mutations
- route status/redirect behaviour
- lifecycle controls rendered only for appropriate statuses and permissions

When testing returned route action data, remember React Router actions may return either a `Response` or data-with-response-init. Narrow the result before accessing `.data` when TypeScript requires it.

## Payment Testing

Payment behaviour should be covered with focused tests for:

- recording a positive Payment on an issued Invoice
- rejecting Payments on draft Invoices
- rejecting Payments on voided Invoices
- rejecting zero and negative amounts
- rejecting overpayments
- allowing multiple Payments up to exactly the Invoice total
- derived active amount paid
- derived remaining balance
- voiding a Payment
- voided Payments no longer contributing to amount paid
- preserving voided Payment history
- rejecting repeated Payment voids
- nested Invoice/Payment ownership
- authorization
- route validation/status/redirect behaviour
- Payment controls rendered only for appropriate Invoice states and permissions

For Drizzle `INSERT ... SELECT`, raw SQL expressions selected into inserted columns must be assigned aliases when required by Drizzle's type system.

Use imported Drizzle predicates such as `eq(...)` in `.where(...)`; do not use unsupported callback-style predicates.

---

# Feature Development

Develop features incrementally as vertical slices.

A good vertical slice should include only what is required to deliver one useful end-to-end behaviour.

A slice may include:

- schema/migration changes

- server feature behaviour

- query behaviour

- route adapters

- UI

- focused tests

Do not implement future slices pre-emptively.

When implementing Job editing, do not also add:

- Customer reassignment

- reopening

- moving `in_progress` back to `scheduled`

- status-history timeline UI

- invoice generation

- recurring Jobs

- operator assignment

- calendar views

- generic status-transition frameworks

unless explicitly requested.

---

# File Creation

Before creating a file, ask:

1. Does this represent one meaningful concept?

2. Does an existing file already own this responsibility?

3. Is this abstraction required now?

4. Does its location match repository architecture?

Do not create placeholder files for hypothetical future behaviour.

Do not create index/barrel files unless the existing repository consistently uses them and they provide actual value.

---

# Scope Discipline

Implement only the requested task.

Do not:

- rename unrelated files

- reorganize unrelated directories

- reformat large unrelated areas

- rewrite working code for personal preference

- introduce unrelated dependencies

- clean up unrelated TODOs

- alter CI or deployment workflows unless required

- change authentication architecture unless required

If a small nearby change is essential for correctness, keep it tightly scoped and explain it in the final summary.

---

# Before Finishing

Before considering work complete:

1. Review the diff for unrelated changes.

2. Run the relevant test suite.

3. Run TypeScript/type checking using the project's existing command.

4. Run linting/formatting using the project's existing commands where applicable.

5. Confirm authorization is enforced server-side.

6. Confirm Job status remains derived from status history.

7. Confirm legal transitions are enforced server-side.

8. Confirm active Jobs includes both `scheduled` and `in_progress`.

9. Confirm Job History contains `completed` and `cancelled`.

10. Confirm Customer cannot be changed after Job creation.

11. Confirm ordinary editing is allowed only while scheduled or in progress, and never changes service price.

12. Confirm scheduled date can only change while the Job is `scheduled`.

13. Confirm metadata edits do not modify Job status history.

14. Confirm active-list actions use the same domain operations as detail-page actions.

15. Confirm redirect handling cannot create an open redirect.

16. Confirm tests mirror production structure.

17. Confirm new UI follows `UX-DESIGN.md` and established shared visual/structural conventions when that document is present.

18. Confirm no unnecessary abstractions were introduced.

19. Confirm draft Invoices have no Invoice number and numbers are allocated only on issue.

20. Confirm one Job cannot belong to more than one active Invoice.

21. Confirm all Jobs on one Invoice belong to the same Customer.

22. Confirm issued and voided Invoices and Invoice Items are immutable.

23. Confirm voiding preserves historical Invoice/Job associations while releasing Jobs for reinvoicing.

24. Confirm changing a draft's Job selection preserves Invoice Items for retained Jobs, removes items for removed Jobs, and snapshots only newly-added Jobs.

25. Confirm any Invoice Item mutation is limited to draft Invoices and enforces nested Invoice/Item ownership.

26. Confirm Dashboard UI follows the approved populated/empty reference layouts, uses Invoices overdue rather than Customers overdue, and does not fabricate overdue data when due-date support is absent.

Report:

- what changed

- important design decisions

- tests/checks run

- any assumptions or limitations

Do not claim a test or check passed unless it was actually run successfully.

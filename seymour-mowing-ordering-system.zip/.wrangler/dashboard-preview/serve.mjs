import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
const files = {'/empty.html':['empty.html','text/html'], '/populated.html':['populated.html','text/html'], '/preview.css':['preview.css','text/css'], '/seymour-logo-800.png':['seymour-logo-800.png','image/png']};
createServer((req,res)=>{const file=files[req.url];if(!file){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',file[1]);res.end(readFileSync(new URL(file[0],import.meta.url)));}).listen(5174,'127.0.0.1');

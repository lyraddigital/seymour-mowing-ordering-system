import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router";
import { writeFileSync, readFileSync } from "node:fs";
import DashboardPage from "../../app/ui/features/dashboard/pages/dashboard-page/dashboard-page";
import AppShell from "../../app/ui/layouts/app-shell/app-shell";
import "../../app/ui/styles/global.css";
const base = { today: "2026-09-22", outstandingCents: 0, unpaidInvoiceCount: 0, paymentsReceivedThisMonthCents: 0, overdue: null, unpaidInvoices: [], recentPayments: [], todaysJobs: { scheduled: 0, in_progress: 0, completed: 0, cancelled: 0, total: 0, remaining: 0 } };
for (const populated of [false, true]) {
 const data = populated ? { ...base, outstandingCents: 148000, unpaidInvoiceCount: 5, paymentsReceivedThisMonthCents: 120000,
 unpaidInvoices: Array.from({length:5}, (_, i) => ({id:`inv${i}`,invoiceNumber:`INV-00000${i+1}`,customerId:`c${i}`,customerName:["Anderson Family","Thomas Residence","White Property","Martin Homes","Clark Residence"][i],issuedAt:1,paidCents:i%2?0:10000,balanceCents:12000+i*2000})),
 recentPayments: Array.from({length:5}, (_,i) => ({id:`p${i}`,invoiceId:`inv${i}`,invoiceNumber:`INV-00000${i+1}`,customerId:`c${i}`,customerName:["Roberts Family","Davis Property","Walker Residence","Young Family","King Property"][i],amountCents:22000,receivedAt:1790000000000-i*86400000,voidedAt:i===4?1790000000001:null})),
 todaysJobs:{scheduled:6,in_progress:2,completed:3,cancelled:1,total:12,remaining:8} } : base;
 const html=renderToStaticMarkup(<MemoryRouter initialEntries={["/dashboard"]}><AppShell currentUser={{id:"preview",displayName:"Local Developer",email:"developer@example.test",role:"admin"}}><DashboardPage dashboard={data}/></AppShell></MemoryRouter>);
 writeFileSync(`.wrangler/dashboard-preview/${populated?"populated":"empty"}.html`, `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/preview.css"></head><body>${html}</body></html>`);
}

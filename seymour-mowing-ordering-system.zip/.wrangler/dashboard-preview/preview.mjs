// .wrangler/dashboard-preview/preview.tsx
import { renderToStaticMarkup } from "react-dom/server";
import { MemoryRouter } from "react-router";
import { writeFileSync } from "node:fs";

// app/ui/features/dashboard/pages/dashboard-page/dashboard-page.tsx
import { Link } from "react-router";

// app/ui/components/icon/icon.tsx
import { jsx } from "react/jsx-runtime";
var paths = {
  dashboard: "m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z",
  customers: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 4a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.87M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  jobs: "M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2M7 14h2M15 14h2M7 18h2",
  invoice: "M14 2H5v20h14V7zM14 2v6h5M8 12h8M8 16h6",
  payment: "M3 4h18v16H3zM3 9h18M7 15h4",
  contact: "M5 3h4l2 5-3 2a16 16 0 0 0 6 6l2-3 5 2v4c0 2-2 3-4 2C9 19 5 15 3 7 2 5 3 3 5 3z",
  address: "M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0zM15 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  notes: "M5 3h14v18H5zM8 7h8M8 11h8M8 15h5",
  finance: "M3 21h18M5 18v-6h3v6M11 18V7h3v11M17 18V3h3v15",
  balance: "M12 3v18M7 21h10M4 7h16M6 7l-4 8h8zM18 7l-4 8h8z",
  danger: "m12 3 10 18H2zM12 9v5M12 17v.1",
  mail: "M3 5h18v14H3zM3 5l9 7 9-7",
  edit: "m16 3 5 5-12 12-6 1 1-6zM13 6l5 5",
  archive: "M3 4h18v4H3zM5 8v13h14V8M9 12h6",
  plus: "M12 5v14M5 12h14",
  user: "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0M4 21v-2a8 8 0 0 1 16 0v2"
};
function Icon({ name, className }) {
  return /* @__PURE__ */ jsx(
    "svg",
    {
      className,
      width: "22",
      height: "22",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": "true",
      focusable: "false",
      children: /* @__PURE__ */ jsx("path", { d: paths[name] })
    }
  );
}

// app/ui/styles/product.module.css
var product_default = {
  page: "product_page",
  formPage: "product_page product_formPage",
  header: "product_header",
  intro: "product_intro",
  breadcrumb: "product_breadcrumb",
  primaryAction: "product_primaryAction",
  secondaryAction: "product_secondaryAction",
  dangerAction: "product_dangerAction",
  badge: "product_badge",
  active: "product_badge product_active",
  issued: "product_badge product_issued",
  archived: "product_badge product_archived",
  draft: "product_badge product_draft",
  voided: "product_badge product_voided",
  tabs: "product_tabs",
  emptyState: "product_emptyState",
  tableScroll: "product_tableScroll",
  table: "product_table",
  numeric: "product_numeric",
  view: "product_view",
  iconCircle: "product_iconCircle",
  sectionHeading: "product_sectionHeading",
  metrics: "product_metrics"
};

// app/ui/features/dashboard/pages/dashboard-page/dashboard-page.module.css
var dashboard_page_default = {
  metrics: "dashboard_page_metrics",
  panel: "dashboard_page_panel",
  context: "dashboard_page_context",
  unavailable: "dashboard_page_unavailable",
  danger: "dashboard_page_danger",
  warning: "dashboard_page_warning",
  sections: "dashboard_page_sections",
  attention: "dashboard_page_attention",
  unpaid: "dashboard_page_unpaid",
  payments: "dashboard_page_payments",
  jobs: "dashboard_page_jobs",
  sectionHeading: "dashboard_page_sectionHeading",
  viewAll: "dashboard_page_viewAll",
  empty: "dashboard_page_empty",
  table: "dashboard_page_table",
  voided: "dashboard_page_voided",
  jobMetrics: "dashboard_page_jobMetrics",
  jobContext: "dashboard_page_jobContext"
};

// app/ui/features/dashboard/pages/dashboard-page/dashboard-page.tsx
import { Fragment, jsx as jsx2, jsxs } from "react/jsx-runtime";
var currency = new Intl.NumberFormat("en-AU", {
  style: "currency",
  currency: "AUD"
});
var date = new Intl.DateTimeFormat("en-AU", {
  timeZone: "Australia/Melbourne",
  day: "numeric",
  month: "short",
  year: "numeric"
});
function EmptyState({
  icon,
  title,
  children
}) {
  return /* @__PURE__ */ jsxs("div", { className: dashboard_page_default.empty, children: [
    /* @__PURE__ */ jsx2("span", { className: product_default.iconCircle, children: /* @__PURE__ */ jsx2(Icon, { name: icon }) }),
    /* @__PURE__ */ jsx2("h3", { children: title }),
    /* @__PURE__ */ jsx2("p", { children })
  ] });
}
function DashboardPage({ dashboard }) {
  const { todaysJobs } = dashboard;
  return /* @__PURE__ */ jsxs("div", { className: product_default.page, children: [
    /* @__PURE__ */ jsx2("header", { className: product_default.header, children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx2("h1", { className: "page-title", children: "Dashboard" }),
      /* @__PURE__ */ jsx2("p", { className: product_default.intro, children: "Financial health and operational activity at a glance." })
    ] }) }),
    /* @__PURE__ */ jsxs("dl", { className: dashboard_page_default.metrics, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx2("span", { className: product_default.iconCircle, children: /* @__PURE__ */ jsx2(Icon, { name: "balance" }) }),
        /* @__PURE__ */ jsx2("dt", { children: "Outstanding balance" }),
        /* @__PURE__ */ jsx2("dd", { children: currency.format(dashboard.outstandingCents / 100) }),
        /* @__PURE__ */ jsxs("dd", { className: dashboard_page_default.context, children: [
          "Across ",
          dashboard.unpaidInvoiceCount,
          " unpaid invoices"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx2("span", { className: `${product_default.iconCircle} ${dashboard_page_default.danger}`, children: /* @__PURE__ */ jsx2(Icon, { name: "danger" }) }),
        /* @__PURE__ */ jsx2("dt", { children: "Overdue balance" }),
        /* @__PURE__ */ jsx2("dd", { className: dashboard_page_default.unavailable, children: "Unavailable" }),
        /* @__PURE__ */ jsx2("dd", { className: dashboard_page_default.context, children: "Invoice due dates required" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx2("span", { className: `${product_default.iconCircle} ${dashboard_page_default.warning}`, children: /* @__PURE__ */ jsx2(Icon, { name: "invoice" }) }),
        /* @__PURE__ */ jsx2("dt", { children: "Invoices overdue" }),
        /* @__PURE__ */ jsx2("dd", { className: dashboard_page_default.unavailable, children: "Unavailable" }),
        /* @__PURE__ */ jsx2("dd", { className: dashboard_page_default.context, children: "Invoice due dates required" })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx2("span", { className: product_default.iconCircle, children: /* @__PURE__ */ jsx2(Icon, { name: "finance" }) }),
        /* @__PURE__ */ jsx2("dt", { children: "Payments received this month" }),
        /* @__PURE__ */ jsx2("dd", { children: currency.format(dashboard.paymentsReceivedThisMonthCents / 100) }),
        /* @__PURE__ */ jsx2("dd", { className: dashboard_page_default.context, children: "Active payments \xB7 Melbourne time" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: dashboard_page_default.sections, children: [
      /* @__PURE__ */ jsxs(
        "section",
        {
          className: `${dashboard_page_default.panel} ${dashboard_page_default.attention}`,
          "aria-labelledby": "attention-heading",
          children: [
            /* @__PURE__ */ jsxs("header", { className: `${product_default.sectionHeading} ${dashboard_page_default.sectionHeading}`, children: [
              /* @__PURE__ */ jsx2("span", { className: `${product_default.iconCircle} ${dashboard_page_default.danger}`, children: /* @__PURE__ */ jsx2(Icon, { name: "danger" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx2("h2", { id: "attention-heading", children: "Needs attention" }),
                /* @__PURE__ */ jsx2("p", { children: "Invoices that need your focus." })
              ] }),
              /* @__PURE__ */ jsx2(Link, { className: dashboard_page_default.viewAll, to: "/invoices", children: "View all invoices \u2192" })
            ] }),
            /* @__PURE__ */ jsx2(EmptyState, { icon: "invoice", title: "Overdue information unavailable", children: "Invoice due dates are not available yet, so invoices needing attention cannot be determined." })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        "section",
        {
          className: `${dashboard_page_default.panel} ${dashboard_page_default.unpaid}`,
          "aria-labelledby": "unpaid-heading",
          children: [
            /* @__PURE__ */ jsxs("header", { className: `${product_default.sectionHeading} ${dashboard_page_default.sectionHeading}`, children: [
              /* @__PURE__ */ jsx2(Icon, { name: "invoice" }),
              /* @__PURE__ */ jsx2("h2", { id: "unpaid-heading", children: "Partially paid / unpaid invoices" }),
              /* @__PURE__ */ jsx2(Link, { className: dashboard_page_default.viewAll, to: "/invoices", children: "View all \u2192" })
            ] }),
            dashboard.unpaidInvoices.length ? /* @__PURE__ */ jsx2(
              "div",
              {
                className: product_default.tableScroll,
                role: "region",
                "aria-label": "Unpaid invoices",
                tabIndex: 0,
                children: /* @__PURE__ */ jsxs(
                  "table",
                  {
                    className: `${product_default.table} ${dashboard_page_default.table}`,
                    "aria-label": "Partially paid / unpaid invoices",
                    children: [
                      /* @__PURE__ */ jsx2("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Customer" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Invoice" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Status" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", className: product_default.numeric, children: "Balance" })
                      ] }) }),
                      /* @__PURE__ */ jsx2("tbody", { children: dashboard.unpaidInvoices.map((invoice) => /* @__PURE__ */ jsxs("tr", { children: [
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(Link, { to: `/customers/${invoice.customerId}`, children: invoice.customerName }) }),
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(Link, { to: `/invoices/${invoice.id}`, children: invoice.invoiceNumber }) }),
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(
                          "span",
                          {
                            className: `${product_default.badge} ${invoice.paidCents > 0 ? dashboard_page_default.warning : dashboard_page_default.danger}`,
                            children: invoice.paidCents > 0 ? "Partially paid" : "Unpaid"
                          }
                        ) }),
                        /* @__PURE__ */ jsx2("td", { className: product_default.numeric, children: currency.format(invoice.balanceCents / 100) })
                      ] }, invoice.id)) })
                    ]
                  }
                )
              }
            ) : /* @__PURE__ */ jsx2(EmptyState, { icon: "invoice", title: "No unpaid invoices", children: "All invoices are paid in full. Great work!" })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        "section",
        {
          className: `${dashboard_page_default.panel} ${dashboard_page_default.payments}`,
          "aria-labelledby": "payments-heading",
          children: [
            /* @__PURE__ */ jsxs("header", { className: `${product_default.sectionHeading} ${dashboard_page_default.sectionHeading}`, children: [
              /* @__PURE__ */ jsx2(Icon, { name: "payment" }),
              /* @__PURE__ */ jsx2("h2", { id: "payments-heading", children: "Recent payments" }),
              /* @__PURE__ */ jsx2(Link, { className: dashboard_page_default.viewAll, to: "/payments", children: "View all \u2192" })
            ] }),
            dashboard.recentPayments.length ? /* @__PURE__ */ jsx2(
              "div",
              {
                className: product_default.tableScroll,
                role: "region",
                "aria-label": "Recent payment history",
                tabIndex: 0,
                children: /* @__PURE__ */ jsxs(
                  "table",
                  {
                    className: `${product_default.table} ${dashboard_page_default.table}`,
                    "aria-label": "Recent payments",
                    children: [
                      /* @__PURE__ */ jsx2("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Date" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Customer" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", children: "Invoice" }),
                        /* @__PURE__ */ jsx2("th", { scope: "col", className: product_default.numeric, children: "Amount" })
                      ] }) }),
                      /* @__PURE__ */ jsx2("tbody", { children: dashboard.recentPayments.map((payment) => /* @__PURE__ */ jsxs("tr", { children: [
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(
                          "time",
                          {
                            dateTime: new Date(payment.receivedAt).toISOString(),
                            children: date.format(payment.receivedAt)
                          }
                        ) }),
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(Link, { to: `/customers/${payment.customerId}`, children: payment.customerName }) }),
                        /* @__PURE__ */ jsx2("td", { children: /* @__PURE__ */ jsx2(Link, { to: `/invoices/${payment.invoiceId}`, children: payment.invoiceNumber }) }),
                        /* @__PURE__ */ jsxs("td", { className: product_default.numeric, children: [
                          currency.format(payment.amountCents / 100),
                          payment.voidedAt !== null && /* @__PURE__ */ jsx2("span", { className: `${product_default.voided} ${dashboard_page_default.voided}`, children: "Voided" })
                        ] })
                      ] }, payment.id)) })
                    ]
                  }
                )
              }
            ) : /* @__PURE__ */ jsx2(EmptyState, { icon: "payment", title: "No recent payments", children: "Payments you receive will appear here." })
          ]
        }
      ),
      /* @__PURE__ */ jsxs(
        "section",
        {
          className: `${dashboard_page_default.panel} ${dashboard_page_default.jobs}`,
          "aria-labelledby": "jobs-heading",
          children: [
            /* @__PURE__ */ jsxs("header", { className: `${product_default.sectionHeading} ${dashboard_page_default.sectionHeading}`, children: [
              /* @__PURE__ */ jsx2("span", { className: product_default.iconCircle, children: /* @__PURE__ */ jsx2(Icon, { name: "jobs" }) }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx2("h2", { id: "jobs-heading", children: "Today's jobs" }),
                /* @__PURE__ */ jsx2("p", { children: "A snapshot of today's scheduled work \xB7 Melbourne time." })
              ] }),
              /* @__PURE__ */ jsx2(Link, { className: dashboard_page_default.viewAll, to: "/jobs", children: "View all jobs \u2192" })
            ] }),
            todaysJobs.total ? /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsxs("dl", { className: dashboard_page_default.jobMetrics, children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx2("dt", { children: "Scheduled" }),
                  /* @__PURE__ */ jsx2("dd", { children: todaysJobs.scheduled })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx2("dt", { children: "In progress" }),
                  /* @__PURE__ */ jsx2("dd", { children: todaysJobs.in_progress })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx2("dt", { children: "Completed" }),
                  /* @__PURE__ */ jsx2("dd", { children: todaysJobs.completed })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx2("dt", { children: "Remaining" }),
                  /* @__PURE__ */ jsx2("dd", { children: todaysJobs.remaining })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("p", { className: dashboard_page_default.jobContext, children: [
                todaysJobs.total,
                " jobs today \xB7 ",
                todaysJobs.cancelled,
                " ",
                "cancelled. Remaining includes scheduled and in-progress jobs."
              ] })
            ] }) : /* @__PURE__ */ jsx2(EmptyState, { icon: "jobs", title: "No jobs scheduled today", children: "Enjoy the day! New jobs will appear here when they're scheduled." })
          ]
        }
      )
    ] })
  ] });
}

// app/ui/layouts/app-shell/app-shell.tsx
import { NavLink } from "react-router";
import { jsx as jsx3, jsxs as jsxs2 } from "react/jsx-runtime";
function AppShell({ currentUser, children }) {
  return /* @__PURE__ */ jsxs2("div", { className: "app-shell", children: [
    /* @__PURE__ */ jsx3("a", { className: "skip-link", href: "#main-content", children: "Skip to content" }),
    /* @__PURE__ */ jsxs2("aside", { className: "sidebar", children: [
      /* @__PURE__ */ jsx3("div", { className: "brand", "aria-label": "Seymour Mowing and Maintenance", children: /* @__PURE__ */ jsx3(
        "img",
        {
          src: "/seymour-logo-800.png",
          alt: "Seymour Mowing & Maintenance",
          width: "315",
          height: "358"
        }
      ) }),
      /* @__PURE__ */ jsxs2("nav", { className: "sidebar-nav", "aria-label": "Main navigation", children: [
        /* @__PURE__ */ jsxs2(NavLink, { to: "/dashboard", children: [
          /* @__PURE__ */ jsx3(Icon, { name: "dashboard" }),
          "Dashboard"
        ] }),
        /* @__PURE__ */ jsxs2(NavLink, { to: "/customers", children: [
          /* @__PURE__ */ jsx3(Icon, { name: "customers" }),
          "Customers"
        ] }),
        /* @__PURE__ */ jsxs2(NavLink, { to: "/jobs", children: [
          /* @__PURE__ */ jsx3(Icon, { name: "jobs" }),
          "Jobs"
        ] }),
        /* @__PURE__ */ jsxs2(NavLink, { to: "/invoices", children: [
          /* @__PURE__ */ jsx3(Icon, { name: "invoice" }),
          "Invoices"
        ] }),
        /* @__PURE__ */ jsxs2(NavLink, { to: "/payments", children: [
          /* @__PURE__ */ jsx3(Icon, { name: "payment" }),
          "Payments"
        ] })
      ] }),
      /* @__PURE__ */ jsxs2("div", { className: "account", children: [
        /* @__PURE__ */ jsx3("span", { className: "account-avatar", children: /* @__PURE__ */ jsx3(Icon, { name: "user" }) }),
        /* @__PURE__ */ jsxs2("div", { className: "account-details", children: [
          /* @__PURE__ */ jsx3("strong", { children: currentUser.displayName }),
          /* @__PURE__ */ jsx3("span", { children: currentUser.email }),
          /* @__PURE__ */ jsx3("span", { className: "role", children: currentUser.role })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx3("main", { id: "main-content", className: "workspace", children })
  ] });
}

// .wrangler/dashboard-preview/preview.tsx
import { jsx as jsx4 } from "react/jsx-runtime";
var base = { today: "2026-09-22", outstandingCents: 0, unpaidInvoiceCount: 0, paymentsReceivedThisMonthCents: 0, overdue: null, unpaidInvoices: [], recentPayments: [], todaysJobs: { scheduled: 0, in_progress: 0, completed: 0, cancelled: 0, total: 0, remaining: 0 } };
for (const populated of [false, true]) {
  const data = populated ? {
    ...base,
    outstandingCents: 148e3,
    unpaidInvoiceCount: 5,
    paymentsReceivedThisMonthCents: 12e4,
    unpaidInvoices: Array.from({ length: 5 }, (_, i) => ({ id: `inv${i}`, invoiceNumber: `INV-00000${i + 1}`, customerId: `c${i}`, customerName: ["Anderson Family", "Thomas Residence", "White Property", "Martin Homes", "Clark Residence"][i], issuedAt: 1, paidCents: i % 2 ? 0 : 1e4, balanceCents: 12e3 + i * 2e3 })),
    recentPayments: Array.from({ length: 5 }, (_, i) => ({ id: `p${i}`, invoiceId: `inv${i}`, invoiceNumber: `INV-00000${i + 1}`, customerId: `c${i}`, customerName: ["Roberts Family", "Davis Property", "Walker Residence", "Young Family", "King Property"][i], amountCents: 22e3, receivedAt: 179e10 - i * 864e5, voidedAt: i === 4 ? 1790000000001 : null })),
    todaysJobs: { scheduled: 6, in_progress: 2, completed: 3, cancelled: 1, total: 12, remaining: 8 }
  } : base;
  const html = renderToStaticMarkup(/* @__PURE__ */ jsx4(MemoryRouter, { initialEntries: ["/dashboard"], children: /* @__PURE__ */ jsx4(AppShell, { currentUser: { id: "preview", displayName: "Local Developer", email: "developer@example.test", role: "admin" }, children: /* @__PURE__ */ jsx4(DashboardPage, { dashboard: data }) }) }));
  writeFileSync(`.wrangler/dashboard-preview/${populated ? "populated" : "empty"}.html`, `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/preview.css"></head><body>${html}</body></html>`);
}

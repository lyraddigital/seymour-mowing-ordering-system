import { build } from 'esbuild';
await build({ entryPoints: [process.cwd() + '/.wrangler/dashboard-preview/preview.tsx'], bundle:true, platform:'node',format:'esm',packages:'external',jsx:'automatic',outfile:'.wrangler/dashboard-preview/preview.mjs' });

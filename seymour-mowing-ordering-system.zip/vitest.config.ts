import { defineConfig } from "vitest/config";

// Separate from the app Vite config: tests do not start the SSR dev server.
export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/**/*.test.{ts,tsx}"],
  },
});
